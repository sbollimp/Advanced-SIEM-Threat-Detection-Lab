# Detection Engineering Lab — Advanced SIEM & Threat Detection

A self-built Security Operations Center (SOC) environment for simulating real-world attack chains and building, testing, and tuning the detection logic that catches them.

This repo documents the full lab: the architecture, the tools, the attack simulations run against it, the Sigma and YARA detection rules written to catch them, and the methodology used to measure detection improvement.

## Summary

| | |
|---|---|
| **Goal** | Build a realistic, multi-tool SOC lab and validate detection coverage against common attacker behavior |
| **Stack** | Splunk, Elastic SIEM (ELK), Wazuh, Sysmon, Security Onion, Kali Linux, AWS (CloudTrail/VPC Flow Logs) |
| **Detection content** | Custom Sigma rules and YARA signatures |
| **Simulated attack chains** | Brute-force access, lateral movement, data exfiltration |
| **Result** | 52% improvement in detection accuracy after rule tuning (see [docs/detection-accuracy-results.md](docs/detection-accuracy-results.md)) |

## Repository structure

```
detection-engineering-lab/
├── docs/                      Architecture, lab setup, attack simulations, results
├── sigma-rules/                Vendor-agnostic detection rules (brute-force, lateral movement, exfiltration)
├── yara-rules/                 Signatures for malicious tooling / artifacts observed on endpoints
├── splunk/                     Saved searches / correlation searches used in Splunk
├── elastic/detection_rules/     Elastic Security detection rules (.toml)
├── wazuh/                      Custom Wazuh local rules (Sysmon-based)
├── scripts/                    Attack simulation scripts used to generate telemetry (lab-only)
├── aws/                        Notes on CloudTrail / VPC Flow Log detections
└── assets/                     Architecture diagrams, dashboard screenshots
```

## Architecture

See [docs/architecture.md](docs/architecture.md) for the full diagram and data flow. In short: Kali Linux runs the attacker simulations against a small Windows/Linux target segment; Sysmon and Wazuh agents forward endpoint telemetry; Security Onion sits on a span/mirror port for network visibility; everything lands in both Splunk and Elastic SIEM so detections could be built and compared across both platforms; AWS CloudTrail and VPC Flow Logs were piped in to cover cloud-side detection as well.

## Attack simulations

Three attack chains were run repeatedly against the lab to generate realistic telemetry and validate detections end-to-end:

1. **Brute-force access** — RDP and SSH credential attacks (Kali → Windows/Linux targets)
2. **Lateral movement** — PsExec, WMI, and remote service creation between compromised hosts
3. **Data exfiltration** — staged archive + DNS tunneling and large outbound transfer to an external host

Full write-up, tooling, and MITRE ATT&CK mapping: [docs/attack-simulations.md](docs/attack-simulations.md)

> **Safety note:** every simulation script in `scripts/` is written to run only inside an isolated lab network against lab-owned targets. See [scripts/README.md](scripts/README.md) before running anything.

## Detection content

- **Sigma rules** ([sigma-rules/](sigma-rules/)) — written once, converted to both Splunk SPL and Elastic EQL/KQL with `sigma-cli`, so the same logic runs on both SIEMs.
- **YARA rules** ([yara-rules/](yara-rules/)) — file/memory signatures for tooling and artifacts dropped during the simulations (e.g. credential-dumping tool markers, encoded PowerShell droppers).
- **Wazuh custom rules** ([wazuh/local_rules.xml](wazuh/local_rules.xml)) — Sysmon-driven rules for the same behaviors at the HIDS layer.
- **Elastic detection rules** ([elastic/detection_rules/](elastic/detection_rules/)) — native Elastic Security rule definitions.

## Measuring detection accuracy

Detection accuracy was measured by running each attack chain a fixed number of times against a baseline rule set, then again after a tuning pass (narrowing noisy rules, adding missing log sources, correlating multi-stage behavior instead of single events). The methodology, raw numbers, and the resulting **52% improvement** are in [docs/detection-accuracy-results.md](docs/detection-accuracy-results.md).

## Tools used

`Splunk` · `Elastic SIEM` · `Wazuh` · `Sysmon` · `Security Onion` · `Kali Linux` · `Sigma` · `YARA` · `AWS CloudTrail / VPC Flow Logs`

## Setup

Full environment build steps (VM layout, agent installation, log forwarding, SIEM onboarding) are in [docs/lab-setup.md](docs/lab-setup.md).

## License

MIT — see [LICENSE](LICENSE). Detection rules are free to reuse/adapt in your own lab.
