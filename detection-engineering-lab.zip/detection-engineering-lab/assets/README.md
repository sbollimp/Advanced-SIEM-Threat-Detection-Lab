# Assets

Drop screenshots and exported diagrams here before pushing to GitHub, e.g.:

- `architecture-diagram.png` — exported version of the Mermaid diagram in `docs/architecture.md` (GitHub renders the Mermaid code block natively too, so this is optional)
- `splunk-dashboard.png` — screenshot of the Splunk dashboard showing the brute-force/lateral-movement/exfiltration alerts firing
- `elastic-detections.png` — screenshot of the Elastic Security detection rules page with the custom rules enabled
- `wazuh-alerts.png` — screenshot of the Wazuh dashboard showing the custom rule hits
- `before-after-accuracy.png` — a simple bar chart of the baseline vs. tuned detection-accuracy numbers from `docs/detection-accuracy-results.md`

Reference these from the main `README.md` with standard Markdown image syntax once added, e.g.:

```markdown
![Architecture diagram](assets/architecture-diagram.png)
```
