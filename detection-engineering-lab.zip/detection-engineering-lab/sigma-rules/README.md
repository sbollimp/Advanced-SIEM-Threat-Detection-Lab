# Sigma Rules

Vendor-agnostic detection rules written once in [Sigma](https://github.com/SigmaHQ/sigma) format and converted to both Splunk SPL and Elastic EQL/KQL with [`sigma-cli`](https://github.com/SigmaHQ/sigma-cli), so the same logic is validated on both SIEMs in the lab.

## Converting a rule

```bash
pip install sigma-cli
sigma plugin install splunk
sigma plugin install elasticsearch

# Convert to Splunk SPL
sigma convert -t splunk sigma-rules/brute_force_ssh.yml

# Convert to Elastic EQL
sigma convert -t es_eql sigma-rules/brute_force_ssh.yml
```

## Rule index

| Rule | Technique | MITRE ATT&CK |
|---|---|---|
| `brute_force_ssh.yml` | Repeated SSH auth failures followed by a success from one source | T1110.001 |
| `brute_force_rdp.yml` | Repeated RDP logon failures (Event ID 4625) followed by a success (4624) from one source | T1110.001 |
| `lateral_movement_psexec.yml` | Remote service creation consistent with PsExec/Impacket `psexec.py` | T1569.002 |
| `lateral_movement_wmi.yml` | Process creation with `WmiPrvSE.exe` as parent, consistent with WMI lateral movement | T1047 |
| `exfiltration_dns_tunneling.yml` | High-volume, high-entropy DNS TXT/CNAME queries to a single domain | T1071.004 |
| `exfiltration_large_outbound_transfer.yml` | Large single outbound transfer to a rare/external destination shortly after an archive utility runs | T1048, T1560 |

Each rule includes a `falsepositives` field — these were populated from the false positives actually observed during the tuning pass described in [../docs/detection-accuracy-results.md](../docs/detection-accuracy-results.md), not written speculatively.
