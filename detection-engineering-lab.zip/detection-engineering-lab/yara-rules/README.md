# YARA Rules

File/memory signatures used to flag tooling and artifacts dropped on disk during the attack simulations. These are intentionally generic, pattern-based heuristics (string/byte matches) for lab and learning purposes — not a substitute for a maintained threat-intel feed in production.

## Usage

```bash
# Scan a directory
yara -r yara-rules/*.yar /path/to/scan

# Scan a running process's memory (Linux, requires root)
yara -r yara-rules/*.yar <pid>
```

## Rule index

| Rule file | Detects |
|---|---|
| `mimikatz_generic.yar` | Common strings/exports associated with credential-dumping tools in the Mimikatz family |
| `encoded_powershell.yar` | PowerShell invocations using `-EncodedCommand` / `-enc` with Base64-encoded payloads |
| `lateral_movement_tools.yar` | Artifacts of Impacket (`psexec.py`, `wmiexec.py`) and SysInternals PsExec left on disk |
