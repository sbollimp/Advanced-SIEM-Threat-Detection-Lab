rule Impacket_PsExec_WmiExec_Artifacts
{
    meta:
        description = "Flags on-disk artifacts and strings associated with Impacket's psexec.py / wmiexec.py or SysInternals PsExec, used for lateral movement"
        author = "Detection Engineering Lab"
        date = "2026-09-15"
        reference = "https://attack.mitre.org/techniques/T1569/002/"
        mitre_attack = "T1569.002, T1021.002, T1047"

    strings:
        $svc1 = "PSEXESVC" ascii wide
        $svc2 = "RemCom_communicaton" ascii wide
        $imp1 = "impacket" ascii wide nocase
        $imp2 = "wmiexec.py" ascii wide nocase
        $imp3 = "psexec.py" ascii wide nocase
        $pipe = "\\\\.\\pipe\\RemCom_communicaton" ascii wide

    condition:
        any of them
}
